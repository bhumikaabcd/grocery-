package com.vw.project.store;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class StroreController {
	private static Logger log = Logger.getLogger("StroreController");
	@Autowired
	private StoreRepo repo;

	@PostMapping("/add-store")
	public Store addStore(@RequestBody Store store) {
		repo.save(store);
		System.out.println("yes");
		return store;
		
	}
	@PostMapping("/update-store")
	public Store updateStore(@RequestBody Store updateStore) {
		log.info("Store details update initiated...");
		Store store = repo.save(updateStore);
		log.info("Store details update completed...");
		return store;
	}
	@GetMapping("/list-store/{storeId}")
	public Store listStore(@PathVariable int storeId){
		Store s =repo.findById(storeId).get();
		return s;
	}
	@GetMapping("/list-store")
	public List<Store> listStore(){
		return (List<Store>) repo.findAll();
	}
}
