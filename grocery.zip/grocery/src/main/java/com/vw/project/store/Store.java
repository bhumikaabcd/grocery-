package com.vw.project.store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.*;
@Entity
@Table(name = "store")
public class Store {
	@Id
	@Column(name = "storeId")
	private int storeId;
	@Column(name = "storeAddress")
	private String storeAddress;
	@Column(name = "storeVendor")
	private String storeVendor;
	@Column(name = "city")
	private String storeCity;
	@Column(name = "state")
	private String storeState;
	@Column(name = "country")
	private String storeCountry;
	@Column(name = "postalCode")
	private String storePostalCode;
	@Column(name = "storeRatings")
	private int storeRating;
	public Store(int storeId, String storeAddress, String storeVendor, String storeCity, String storeState,
			String storeCountry, String storePostalCode, int storeRating) {
		super();
		this.storeId = storeId;
		this.storeAddress = storeAddress;
		this.storeVendor = storeVendor;
		this.storeCity = storeCity;
		this.storeState = storeState;
		this.storeCountry = storeCountry;
		this.storePostalCode = storePostalCode;
		this.storeRating = storeRating;
	}
	public Store() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getStoreId() {
		return storeId;
	}
	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}
	public String getStoreAddress() {
		return storeAddress;
	}
	public void setStoreAddress(String storeAddress) {
		this.storeAddress = storeAddress;
	}
	public String getStoreVendor() {
		return storeVendor;
	}
	public void setStoreVendor(String storeVendor) {
		this.storeVendor = storeVendor;
	}
	public String getStoreCity() {
		return storeCity;
	}
	public void setStoreCity(String storeCity) {
		this.storeCity = storeCity;
	}
	public String getStoreState() {
		return storeState;
	}
	public void setStoreState(String storeState) {
		this.storeState = storeState;
	}
	public String getStoreCountry() {
		return storeCountry;
	}
	public void setStoreCountry(String storeCountry) {
		this.storeCountry = storeCountry;
	}
	public String getStorePostalCode() {
		return storePostalCode;
	}
	public void setStorePostalCode(String storePostalCode) {
		this.storePostalCode = storePostalCode;
	}
	public int getStoreRating() {
		return storeRating;
	}
	public void setStoreRating(int storeRating) {
		this.storeRating = storeRating;
	}

}

	