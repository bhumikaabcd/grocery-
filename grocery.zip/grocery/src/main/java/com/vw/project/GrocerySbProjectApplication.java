package com.vw.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@EnableJpaRepositories(basePackages = "com.vw.project")
@SpringBootApplication
public class GrocerySbProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrocerySbProjectApplication.class, args);
	}
	
	@Bean
	public WebMvcConfigurer crossConfig() {
		WebMvcConfigurer config = new WebMvcConfigurer() {
			public void addCorsMappings(CorsRegistry reg) {
				reg.addMapping("/**").allowedOrigins("http://localhost:4200");
			}
		};
		return config;
	}

}