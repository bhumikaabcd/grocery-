package com.vw.project.order;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="orders")
public class Order {

	private transient int customerId;

	@Id
	@Column(name="orderId")
	private int orderId;
	@Column(name="quantityOrdered")
	private int quantityOrdered;
	@Column(name="productCode")
	private int productCode;

	public Order() {
		super();

	}

	public Order(int orderId, int quantityOrdered, int productCode, int customerId) {
		super();
		this.orderId = orderId;
		this.quantityOrdered = quantityOrdered;
		this.productCode = productCode;
		this.customerId = customerId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getQuantityOrdered() {
		return quantityOrdered;
	}

	public void setQuantityOrdered(int quantityOrdered) {
		this.quantityOrdered = quantityOrdered;
	}

	public int getProductCode() {
		return productCode;
	}

	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}

}
