package com.vw.project.store;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface StoreRepo extends CrudRepository<Store,Integer> {

	
	List<Store> findByStoreIdLessThan(int storeId);
	
}
