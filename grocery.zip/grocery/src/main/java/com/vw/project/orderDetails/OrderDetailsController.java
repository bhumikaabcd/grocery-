package com.vw.project.orderDetails;



import javax.annotation.PostConstruct;
import java.time.LocalDate;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
/*
<<<<<<< HEAD
import com.vw.project.customerDetails.CustomerDetails;
=======
import com.vw.project.order.Order;
>>>>>>> 73e01f4be702cd5db2db1bbe3e9a95ec7812d1dc
*/
@RestController
public class OrderDetailsController {
	
	@Autowired 
	private OrderDetailsRepo repo;
	
	
	
	@GetMapping("/remove-orderDetails/{id}")
	public void removeOrderDetails(@PathVariable("id") int orderId) { 
		repo.deleteById(orderId);
		//Order or = repo.deleteById(orderid);
	}
	
//	@GetMapping(value = "/change_address", consumes = MediaType.APPLICATION_JSON_VALUE)
//	public CustomerDetails changeAddress(@RequestBody CustomerDetails cd) {
//		logger.info("+++++++++"+cd.getAddress());
//		return repo.save(cd);
//	}
	
	@GetMapping("/find-orderDetails/{id}")
	public OrderDetails findOrderDetails(@PathVariable("id") int orderId ) {
		return repo.findById(orderId).get();
	}
	
	@GetMapping("/find-allOrderDetails/{customerId}")
	public Iterable<OrderDetails> findallOrderDetails(@PathVariable("customerId") int customerId) {
		return repo.findByCustomerId(customerId);
	}


}
