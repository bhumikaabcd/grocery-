package com.vw.project.orderDetails;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderDetailsRepo extends CrudRepository<OrderDetails, Integer>{
	public List<OrderDetails> findByCustomerId(int customerId);
}
