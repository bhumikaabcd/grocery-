package com.vw.project.product;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ProductController {
	
	private static final Logger logger = Logger.getLogger("ProductController");
	
	
	@Autowired
	private ProductRepo repo;
	
	@GetMapping(value="/filter-in/{fc}")
	public List<Product> showProductsbyfirstCategory(@PathVariable ("fc") String fc) {
		
		return repo.findByFirstCategory(fc);
		
	}
	
	@GetMapping(value="/products-in/{sc}")
	public List<Product> showProductsbySecondCategory(@PathVariable ("sc") String sc) {
		
		return repo.findBySecondCategory(sc);
		
	}
	
	@GetMapping(value="/product/{productCode}")
	public Product getProduct(@PathVariable ("productCode") int productCode) {
		
		Product product = repo.findByproductCode(productCode);
		
		return product;
	}
	
	
	@PostMapping(value="/add-product")
	public Product addProduct(@RequestBody Product product) {
		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		logger.info("********Product recieved from UI ******");
		Product p = repo.save(product);
		return p;
	}
	
	@GetMapping(value="/Fcategories")
	public List<String> getFCategories(){
		return repo.findDistinctByFirstCategory();
	}
	
	@GetMapping(value = "/Scategories")
	public List<String> getSCategories(){
		return repo.findDistinctBySecondCategory();
	}

}
