package com.vw.project.customerDetails;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="customerdetails")
public class CustomerDetails {
	@Id
	private int customerId;
	private String address;
	private String phone;
	private String savedCards;
	private String postalCode;
	private String city;

	public CustomerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerDetails(int customerId, String address, String phone, String savedCards, String postalCode,
			String city) {
		super();
		this.customerId = customerId;
		this.address = address;
		this.phone = phone;
		this.savedCards = savedCards;
		this.postalCode = postalCode;
		this.city = city;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSavedCards() {
		return savedCards;
	}

	public void setSavedCards(String savedCards) {
		this.savedCards = savedCards;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
