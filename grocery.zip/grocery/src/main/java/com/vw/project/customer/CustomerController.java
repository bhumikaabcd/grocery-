package com.vw.project.customer;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {
	private static final Logger LOG = Logger.getLogger("CustomerController");

	@Autowired
	private CustomerRepo repo;

	@PostMapping("/add-customer")
	public Customer addCustomer(@RequestBody Customer customer) {
		repo.save(customer);
		return customer;

	}

	@GetMapping(value="/find-customer/{cId}")
	public Customer findCustomer(@PathVariable int cId) {
		System.out.println("*************************************");
		System.out.println(repo.findById(cId).get());
		return repo.findById(cId).get();
	}
	
}
