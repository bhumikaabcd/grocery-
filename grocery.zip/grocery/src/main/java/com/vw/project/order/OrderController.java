package com.vw.project.order;

import java.time.LocalDate;
import java.util.Optional;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.vw.project.orderDetails.OrderDetails;
import com.vw.project.orderDetails.OrderDetailsRepo;
import com.vw.project.product.Product;
import com.vw.project.product.ProductRepo;

@RestController
public class OrderController {

	private static Logger logger = Logger.getLogger(OrderController.class);
	@Autowired
	private OrderRepo repo;
	@Autowired
	private OrderDetailsRepo detrepo;
	@Autowired
	private ProductRepo productRepo;

	@PostMapping(value = "/delete-order", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void deleteOrder(@RequestBody int orderId) {
		try {
			detrepo.deleteById(orderId);
			repo.deleteById(orderId);
		} catch (Exception ex) {
			logger.info("==========");
		}
	}

	@GetMapping("/fetch-order/{orderId}")
	public Optional<Order> getOrder(@PathVariable int orderId) {
		Optional<Order> order = null;
		try {
			order = repo.findById(orderId);
		} catch (Exception ex) {
			return null;
		}
		return order;
	}

	@PostMapping(value = "/updateorder", consumes = MediaType.APPLICATION_JSON_VALUE)
	public Order updateOrder(@RequestBody Order order) {
		Order o = new Order();
		try {
			o = repo.save(order);

		} catch (Exception ex) {

		}
		return o;
	}

	@PostMapping(value = "/addorder", consumes = MediaType.APPLICATION_JSON_VALUE)
	public Order addOrder(@RequestBody Order order) {
		try {
			logger.info("==========" + order.getOrderId());
			repo.save(order);
			OrderDetails od = new OrderDetails();
			od.setOrderId(order.getOrderId());
			od.setCustomerId(order.getCustomerId());
			od.setOrderDate(LocalDate.now());
			od.setShippedDate(od.getOrderDate().plusDays(2));
			od.setDeliveryDate(od.getShippedDate().plusDays(2));
			detrepo.save(od);
		} catch (Exception ex) {
			logger.info(ex);
		}
		return order;
	}

	@PostMapping(value = "/calculatePrice", consumes = MediaType.APPLICATION_JSON_VALUE)
	public Double calculatePrice(@RequestBody Order order) {
		try {
			Product product = productRepo.findByproductCode(order.getProductCode());
			return product.getMrp() * order.getQuantityOrdered();
		} catch (Exception e) {
			return 0.0;
		}
	}
}
