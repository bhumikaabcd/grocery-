package com.vw.project.customer;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.vw.project.customerDetails.CustomerDetails;

@Repository
public interface CustomerRepo extends CrudRepository<Customer, Integer> {
	
	
}
