package com.vw.project.product;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="products")
public class Product {
	
	@Id
	private int productCode;
	private String productName;
	private double mrp;
	private int quantity;
	private String description;
	private double discountedPrice;
	private String vendor;
	private String firstCategory;
	private String secondCategory;
	private String image;
	
	public Product() {};
	
	public Product(int productCode, String productName, double mrp, int quantity, String description,
			double discountedPrice, String vendor, String firstCategory, String secondCategory,
			String image) {
		super();
		this.productCode = productCode;
		this.productName = productName;
		this.mrp = mrp;
		this.quantity = quantity;
		this.description = description;
		this.discountedPrice = discountedPrice;
		this.vendor = vendor;
		this.firstCategory = firstCategory;
		this.secondCategory = secondCategory;
		this.image = image;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getMrp() {
		return mrp;
	}
	public void setMrp(double mrp) {
		this.mrp = mrp;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getDiscountedPrice() {
		return discountedPrice;
	}
	public void setDiscountedPrice(double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public String getFirstCategory() {
		return firstCategory;
	}
	public void setFirstCategory(String firstCategory) {
		this.firstCategory = firstCategory;
	}
	public String getSecondCategory() {
		return secondCategory;
	}
	public void setSecondCategory(String secondCategory) {
		this.secondCategory = secondCategory;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
	
	

}
