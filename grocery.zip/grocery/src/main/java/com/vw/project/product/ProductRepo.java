package com.vw.project.product;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepo extends CrudRepository<Product, Integer> {
	
	List<Product> findBymrpLessThan(double mrp);
	
	List<Product> findByFirstCategory (String firstCategory);
	
	List<Product> findBySecondCategory (String secondCategory);
	
	Product findByproductCode(int productCode);
	
	@Query(value = "SELECT DISTINCT firstCategory FROM Product") 
	List<String> findDistinctByFirstCategory();
	
	@Query(value = "SELECT DISTINCT secondCategory FROM Product")
	List<String> findDistinctBySecondCategory();

}
